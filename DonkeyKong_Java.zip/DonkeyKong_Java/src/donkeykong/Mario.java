package donkeykong;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author M
 */
public class Mario {


public int x=100;
public int y=462;
public int level=1;
public int slope_counter=0;

public int jump_counter=0;
boolean is_jumping=false;

//6 left 4 right
    public int mario_direction=6;
    public boolean mario_is_moving=false;
    
    public boolean mario_on_ladder=false;
    
    Mario(){}

public void marioJump()
{
    if(is_jumping){
        jump_counter++;

        if(jump_counter<=21) y--;
        if(jump_counter>21) y++;

        if(jump_counter==42){jump_counter=0; is_jumping=false;}
    }
    
}

public void restartMario()
{
    x=100;
    y=462;
    level=1;
    slope_counter=0;
    jump_counter=0;
    is_jumping=false;
    //6 left 4 right
    mario_direction=6;
    mario_is_moving=false;
    mario_on_ladder=false;
}

public void checkMoveRight()
{

    if(level==1)
    {
        
        if(x>=198)
        {
        slope_counter++;if(slope_counter>=32){y=y-2;slope_counter=0;} 
        }
    }
    
    if(level==2)
    {
        //if(x>=198)
        {
        slope_counter++;if(slope_counter>=32){y=y+2;slope_counter=0;} 
        }
    }
    
    if(level==3)
    {
        if(x>=10)
        {
        slope_counter++;if(slope_counter>=32){y=y-2;slope_counter=0;} 
        }
    }
    
    if(level==4)
    {
        //if(x>=10)
        {
        slope_counter++;if(slope_counter>=32){y=y+2;slope_counter=0;} 
        }
    }
    
    if(level==5)
    {
        if(x>=10)
        {
        slope_counter++;if(slope_counter>=32){y=y-2;slope_counter=0;} 
        }
    }
    
    if(level==6)
    {
        if(x>=254)
        {
        slope_counter++;if(slope_counter>=32){y=y+2;slope_counter=0;} 
        }
    }
    
}

public void checkMoveLeft()
{

    if(level==1)
    {
        if(x>=198)
        {
        slope_counter--;if(slope_counter<=0){y=y+2;slope_counter=32;} 
        }
    }
    
    if(level==2)
    {
        //if(x>=198)
        {
        slope_counter--;if(slope_counter<=0){y=y-2;slope_counter=32;} 
        }
    }
    
    if(level==3)
    {
        if(x>=10)
        {
        slope_counter--;if(slope_counter<=0){y=y+2;slope_counter=32;} 
        }
    }
    
    if(level==4)
    {
        //if(x>=10)
        {
        slope_counter--;if(slope_counter<=0){y=y-2;slope_counter=32;} 
        }
    }
    
    if(level==5)
    {
        if(x>=10)
        {
        slope_counter--;if(slope_counter<=0){y=y+2;slope_counter=32;} 
        }
    }
    
    if(level==6)
    {
        if(x>=254)
        {
        slope_counter--;if(slope_counter<=0){y=y-2;slope_counter=32;} 
        }
    }
    
}

public void checkLadderUp()
{
    if(level==1||level==2)
    {
        if(x>=350&&x<=370)
        {
            if(y>408) {mario_on_ladder=true; y=y-4;}
            if(y<=408) {mario_on_ladder=false; level=2;}
        }
    }
    
    if(level==2||level==3)
    {
        if(x>=175&&x<=195)
        {
            if(y>332) {mario_on_ladder=true; y=y-4;}
            if(y<=332) {mario_on_ladder=false; level=3;}
        }
        
        if(x>=50&&x<=70)
        {
            if(y>340) {mario_on_ladder=true; y=y-4;}
            if(y<=340) {mario_on_ladder=false; level=3;}
        }
    }
    
    if(level==3||level==4)
    {
        if(x>=205&&x<=225)
        {
            if(y>266) {mario_on_ladder=true; y=y-4;}
            if(y<=266) {mario_on_ladder=false; level=4;}
        }
        
        if(x>=350&&x<=370)
        {
            if(y>276) {mario_on_ladder=true; y=y-4;}
            if(y<=276) {mario_on_ladder=false; level=4;}
        }
        
    }
    
    if(level==4||level==5)
    {
        if(x>=125&&x<=145)
        {
            if(y>204) {mario_on_ladder=true; y=y-4;}
            if(y<=204) {mario_on_ladder=false; level=5;}
        }
        
        if(x>=50&&x<=70)
        {
            if(y>209) {mario_on_ladder=true; y=y-4;}
            if(y<=209) {mario_on_ladder=false; level=5;}
        }
    }
    
    if(level==5||level==6)
    {
        if(x>=350&&x<=370)
        {
            if(y>144) {mario_on_ladder=true; y=y-4;}
            if(y<=144) {mario_on_ladder=false; level=6;}
        }
    }
    
    if(level==6||level==7)
    {
        if(x>=245&&x<=270)
        {
            if(y>80) {mario_on_ladder=true; y=y-4;}
            if(y<=80) {mario_on_ladder=false; level=7;}
        }
    }
    
}

public void checkLadderDown()
{
    if(level==2||level==1)
    {
        if(x>=350&&x<=370)
        {
            if(y<452) {mario_on_ladder=true; y=y+4;}
            if(y>=452) {mario_on_ladder=false; level=1;}
        }
    }
    
    if(level==2||level==3)
    {
        if(x>=175&&x<=195)
        {
            if(y<394) {mario_on_ladder=true; y=y+4;}
            if(y>=394) {mario_on_ladder=false; level=2;}
        }
    
    
    if(x>=50&&x<=70)
    {
            if(y<386) {mario_on_ladder=true; y=y+4;}
            if(y>=386) {mario_on_ladder=false; level=2;}
    }
    
    }
    
    if(level==3||level==4)
    {
        if(x>=205&&x<=225)
        {
            if(y<330) {mario_on_ladder=true; y=y+4;}
            if(y>=330) {mario_on_ladder=false; level=3;}
        }
        
        if(x>=350&&x<=370)
        {
            if(y<320) {mario_on_ladder=true; y=y+4;}
            if(y>=320) {mario_on_ladder=false; level=3;}
        }
    }

    if(level==4||level==5)
    {
        if(x>=125&&x<=145)
        {
            if(y<260) {mario_on_ladder=true; y=y+4;}
            if(y>=260) {mario_on_ladder=false; level=4;}
        }
        
        if(x>=50&&x<=70)
        {
            if(y<256) {mario_on_ladder=true; y=y+4;}
            if(y>=256) {mario_on_ladder=false; level=4;}
        }
    }
    
    if(level==5||level==6)
    {
        if(x>=350&&x<=370)
        {
            if(y<189) {mario_on_ladder=true; y=y+4;}
            if(y>=189) {mario_on_ladder=false; level=5;}
        }
    }

    if(level==6||level==7)
    {
        if(x>=245&&x<=270)
        {
            if(y<136) {mario_on_ladder=true; y=y+4;}
            if(y>=136) {mario_on_ladder=false; level=6;}
        }
    }
    
}

}
