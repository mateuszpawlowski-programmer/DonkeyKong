package donkeykong;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;


public class DonkeyKong extends JPanel implements Runnable,KeyListener{
    
    public JPanel panel=new JPanel();
    public JFrame frame=new JFrame("Donkey Kong");
    public Thread thread;
    
    BufferedImage  level;
    BufferedImage  barrel_0_f;
    BufferedImage  barrel_1_f;
    BufferedImage  barrel_2_f;
    BufferedImage  barrel_3_f;
    
    BufferedImage  mario_0_right_f;
    BufferedImage  mario_1_right_f;
    BufferedImage  mario_0_left_f;
    BufferedImage  mario_1_left_f;
    
    BufferedImage  kong_1_f;
    BufferedImage  kong_2_f;
    
    BufferedImage  heart;
    
    BufferedImage  level_complete_title;
    BufferedImage  game_over_title;
    
    //BufferedImage barrel_0 = new BufferedImage(20,16,BufferedImage.TYPE_INT_ARGB);
    //BufferedImage barrel_1 = new BufferedImage(20,16,BufferedImage.TYPE_INT_ARGB);
    //BufferedImage barrel_2 = new BufferedImage(20,16,BufferedImage.TYPE_INT_ARGB);
    //BufferedImage barrel_3 = new BufferedImage(20,16,BufferedImage.TYPE_INT_ARGB);
    
    BufferedImage barrel_0 = new BufferedImage(24,20,BufferedImage.TYPE_INT_ARGB);
    BufferedImage barrel_1 = new BufferedImage(24,20,BufferedImage.TYPE_INT_ARGB);
    BufferedImage barrel_2 = new BufferedImage(24,20,BufferedImage.TYPE_INT_ARGB);
    BufferedImage barrel_3 = new BufferedImage(24,20,BufferedImage.TYPE_INT_ARGB);
    
    BufferedImage  mario_0_right= new BufferedImage(32,32,BufferedImage.TYPE_INT_ARGB);
    BufferedImage  mario_1_right= new BufferedImage(32,32,BufferedImage.TYPE_INT_ARGB);
    BufferedImage  mario_0_left= new BufferedImage(32,32,BufferedImage.TYPE_INT_ARGB);
    BufferedImage  mario_1_left= new BufferedImage(32,32,BufferedImage.TYPE_INT_ARGB);
    
    BufferedImage  kong_1= new BufferedImage(80,77,BufferedImage.TYPE_INT_ARGB);
    BufferedImage  kong_2= new BufferedImage(80,77,BufferedImage.TYPE_INT_ARGB);
    
    public int barrel_time_counter=0;
    public int x=0;
    public int anim_counter=0;
    
    public boolean leftKeyDown=false,rightKeyDown=false;
    public boolean showCollision=false;
    
    public Mario mario=new Mario();
    
    public boolean level_complete=false;
    public boolean kong_bouncing=false;
    public int kong_bounce=0;
    public int kong_y=0;
    
    public boolean game_over=false;
    public int game_over_counter=0;
    
    public ArrayList<Barrel> barrel_list=new ArrayList<Barrel>();
    
    public static void main(String[] args) {
        DonkeyKong dk=new DonkeyKong();
        dk.panel = dk;
        dk.frame = new JFrame("DonkeyKong");
        dk.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        dk.frame.getContentPane().add(dk.panel);
        dk.panel.setSize(300, 300);
        dk.frame.setLocation(500, 100);
        dk.frame.pack();
        dk.frame.show();
        dk.thread=new Thread(dk);
        dk.thread.start();
    }

    DonkeyKong()
    {
        try{
        barrel_list.add(new Barrel(55,152,mario));
        
        heart=ImageIO.read(new File("Heart.png"));
        
        level_complete_title=ImageIO.read(new File("level_complete.png"));
        game_over_title=ImageIO.read(new File("game_over.png"));
                
        level=ImageIO.read(new File("level_high_res.png"));
        
        //barrel_0_f=ImageIO.read(new File("barrel_0_high_res.png"));
        //barrel_1_f=ImageIO.read(new File("barrel_1_high_res.png"));
        //barrel_2_f=ImageIO.read(new File("barrel_2_high_res.png"));
        //barrel_3_f=ImageIO.read(new File("barrel_3_high_res.png"));
        
        barrel_0_f=ImageIO.read(new File("barrel_0.png"));
        barrel_1_f=ImageIO.read(new File("barrel_1.png"));
        barrel_2_f=ImageIO.read(new File("barrel_2.png"));
        barrel_3_f=ImageIO.read(new File("barrel_3.png"));
        
        mario_0_right_f=ImageIO.read(new File("mario_right_0_high_res.png"));
        mario_1_right_f=ImageIO.read(new File("mario_right_1_high_res.png"));
       
        mario_0_left_f=ImageIO.read(new File("mario_left_0_high_res.png"));
        mario_1_left_f=ImageIO.read(new File("mario_left_1_high_res.png"));
    
        kong_1_f=ImageIO.read(new File("Kong.png"));
        kong_2_f=ImageIO.read(new File("Kong.png"));
        //System.out.println(""+barrel_0_f.getRGB(0, 0));
        
        //for(int y=0;y<16;y++){
        //for(int x=0;x<20;x++){
        for(int y=0;y<20;y++){
        for(int x=0;x<24;x++){
            if(barrel_0_f.getRGB(x, y)!=-16777216){barrel_0.setRGB(x, y,0+barrel_0_f.getRGB(x, y));}
            
            if(barrel_1_f.getRGB(x, y)!=-16777216){barrel_1.setRGB(x, y,0+barrel_1_f.getRGB(x, y));}
            if(barrel_2_f.getRGB(x, y)!=-16777216){barrel_2.setRGB(x, y,0+barrel_2_f.getRGB(x, y));}
            if(barrel_3_f.getRGB(x, y)!=-16777216){barrel_3.setRGB(x, y,0+barrel_3_f.getRGB(x, y));}
        }
        }
        
        for(int y=0;y<32;y++){
        for(int x=0;x<32;x++){
            if(mario_0_right_f.getRGB(x, y)!=-16777216){mario_0_right.setRGB(x, y,0+mario_0_right_f.getRGB(x, y));}
            if(mario_1_right_f.getRGB(x, y)!=-16777216){mario_1_right.setRGB(x, y,0+mario_1_right_f.getRGB(x, y));}
            
            if(mario_0_left_f.getRGB(x, y)!=-16777216){mario_0_left.setRGB(x, y,0+mario_0_left_f.getRGB(x, y));}
            if(mario_1_left_f.getRGB(x, y)!=-16777216){mario_1_left.setRGB(x, y,0+mario_1_left_f.getRGB(x, y));}
        }
        }
        
        for(int y=0;y<77;y++){
        for(int x=0;x<80;x++){
            if(kong_1_f.getRGB(x, y)!=-16777216){kong_1.setRGB(x, y,0+kong_1_f.getRGB(x, y));}
            if(kong_1_f.getRGB(x, y)!=-16777216){kong_2.setRGB(x, 77-y,0+kong_1_f.getRGB(x, y));}
        }
        }
        
        this.addKeyListener(this);
        setFocusable(true);
        setFocusTraversalKeysEnabled(false);
        }catch(Exception exc){}
    }
    
    public Dimension getPreferredSize(){
        return new Dimension(450, 514);
    }
    
    @Override
    public void run() {
        
        while(true)
        {
            
            if(game_over)
            {
                game_over_counter++;
                if(game_over_counter==200) {game_over_counter=0; game_over=false;}
                mario.restartMario();
            }
            
            //level_complete=true;
            
            if(mario.level==7) level_complete=true;
            if(level_complete)
            {
                if(kong_bouncing==false)
                {
                    if(kong_bounce<2)
                    { 
                        if(kong_y<340) kong_y=kong_y+2;
                        if(kong_y==340) kong_bouncing=true;
                    } else
                    {
                        if(kong_y<450) kong_y=kong_y+2;
                    }
                }
                
                if(kong_bounce<2){
                    if(kong_bouncing)
                    {
                        kong_y=kong_y-2;
                        if(kong_y==300) {kong_bounce++;kong_bouncing=false;}
                    }
                }
            }
            
            mario.marioJump();
            System.out.println(mario.x+" "+mario.y+" level="+mario.level);
            
            if(mario.mario_on_ladder==false)
            {
                if(mario.mario_is_moving&&mario.mario_direction==6) 
                {
                    boolean edge=false;
                    
                    if(mario.level==2&&mario.x>=395) edge=true;
                    //if(mario.level==3&&mario.x<=20) edge=true;
                    
                    if(mario.level==4&&mario.x>=395) edge=true;
                    //if(mario.level==5&&mario.x<=20) edge=true;
                    if(mario.level==6&&mario.x>=395) edge=true;
                    
                    if(mario.level==7&&mario.x>=265) edge=true;
                    
                    if(edge==false){
                    mario.checkMoveRight();
                    mario.x++;
                    }
                }
                
                if(mario.mario_is_moving&&mario.mario_direction==4) 
                {
                    boolean edge=false;
                    
                    //if(mario.level==2&&mario.x>=395) edge=true;
                    if(mario.level==3&&mario.x<=20) edge=true;
                    
                    //if(mario.level==4&&mario.x>=395) edge=true;
                    if(mario.level==5&&mario.x<=20) edge=true;
                    //if(mario.level==6&&mario.x>=395) edge=true;
                    
                    if(edge==false){
                    mario.checkMoveLeft();
                    mario.x--;
                    }
                    
                }
            }
            
            barrel_time_counter++;
            
        try{
    
        
        for(Barrel b:barrel_list)
        {
            //System.out.println(b.x+" "+b.y);
            b.move();
        }
        
        if (barrel_time_counter==400) barrel_list.add(new Barrel(55,152,mario));
        if (barrel_time_counter==800) barrel_list.add(new Barrel(55,152,mario));
        if (barrel_time_counter==1200) barrel_list.add(new Barrel(55,152,mario));
        if (barrel_time_counter==1600) barrel_list.add(new Barrel(55,152,mario));
        
        this.repaint();
        
        //Thread.sleep(15);
        Thread.sleep(10);
        }catch(Exception exc){};
        }
    }

    public void paintComponent(Graphics g){
    	super.paintComponent(g);
        g.setColor(Color.white);
        g.setColor(new Color(255,255,255));
        g.setColor(new Color(0,0,0));
        g.fillRect(0, 0, 672, 864);
        
        
    
        g.drawImage(level, 0,0, null);
        
        anim_counter++;
        if(anim_counter==20) anim_counter=0;
        
        if(level_complete) anim_counter=0;
        
        if(game_over==false){
            if(mario.mario_direction==6||mario.mario_direction==64)
            {
                if(anim_counter<=10) g.drawImage(mario_0_right, mario.x,mario.y, null);
                if(anim_counter>10) g.drawImage(mario_1_right, mario.x,mario.y, null);
            }
        
            if(mario.mario_direction==4||mario.mario_direction==84)
            {
                if(anim_counter<=10) g.drawImage(mario_0_left, mario.x,mario.y, null);
                if(anim_counter>10) g.drawImage(mario_1_left, mario.x,mario.y, null);
            }
        }
        
        if(level_complete==false) g.drawImage(kong_1, 50,90, null);
        
        if(level_complete)
        {
            g.drawImage(kong_2, 50,90+kong_y, null);
            g.drawImage(heart, 250-16,30, null);
            g.drawImage(level_complete_title, 250-64,10, null);
            
        }
        
        if(game_over) g.drawImage(game_over_title, 250-64,260, null);
            
        if(level_complete==false&&game_over==false){
            
        int barrel_correction_y=4;
        
        for(Barrel b:barrel_list)
        {
            if(b.direction==6)
            {
                if(b.frame==0) g.drawImage(barrel_0, b.x,b.y-barrel_correction_y, null);
                if(b.frame==1) g.drawImage(barrel_1, b.x,b.y-barrel_correction_y, null);
                if(b.frame==2) g.drawImage(barrel_2, b.x,b.y-barrel_correction_y, null);
                if(b.frame==3) g.drawImage(barrel_3, b.x,b.y-barrel_correction_y, null);
            }
            
            if(b.direction==4)
            {
                if(b.frame==0) g.drawImage(barrel_3, b.x,b.y-barrel_correction_y, null);
                if(b.frame==1) g.drawImage(barrel_2, b.x,b.y-barrel_correction_y, null);
                if(b.frame==2) g.drawImage(barrel_1, b.x,b.y-barrel_correction_y, null);
                if(b.frame==3) g.drawImage(barrel_0, b.x,b.y-barrel_correction_y, null);
            }
            
            //g.drawImage(barrel_0, 0,0, null);
            g.setColor(Color.white);
            
            if(showCollision)
            {
                g.drawRect(b.x, b.y,24,16);
                g.drawRect(mario.x+16, mario.y+32-10,2,2);
            }
            
            if(b.checkCollisionWithMario())
            {
                g.setColor(Color.white);
                if(showCollision) g.drawLine(b.x, b.y, b.x+24, b.y+16);
                game_over=true;
                //mario.restartMario();
            }
        }
        }
        
    }
    
    public void up()
    {
        mario.mario_is_moving=true;
        
        if(mario.mario_direction==4) mario.mario_direction=84;
        if(mario.mario_direction==6) mario.mario_direction=64;
        
        mario.checkLadderUp();
    }
    public void down()
    {
        mario.mario_is_moving=true;
        //mario.mario_direction=2; 
        if(mario.mario_direction==4) mario.mario_direction=84;
        if(mario.mario_direction==6) mario.mario_direction=64;
        
        mario.checkLadderDown();
    }
    
    public void left()
    {
        if(mario.mario_on_ladder==false){
            mario.mario_is_moving=true;mario.mario_direction=4;leftKeyDown=true;
        }
    }
    
    public void right()
    {
        if(mario.mario_on_ladder==false){
            mario.mario_is_moving=true;mario.mario_direction=6;rightKeyDown=true;
        }
    }
    
    public void jump()
    {
        if(mario.is_jumping==false) mario.is_jumping=true;
    }
    
    @Override
    public void keyTyped(KeyEvent ke) {
        
    }

     @Override
    public void keyPressed(KeyEvent e) {
        if(level_complete==false){
            if(e.getKeyCode()==16){if(mario.mario_on_ladder==false) jump();}
            if(e.getKeyCode()==87){up();}
            if(e.getKeyCode()==83){down();}
            if(e.getKeyCode()==65){left();}
            if(e.getKeyCode()==68){right();}
            if(e.getKeyCode()==74){if(showCollision==false) showCollision=true; else showCollision=false;}
        }
    }

    @Override
    public void keyReleased(KeyEvent ke) {
        
        if(ke.getKeyCode()==65){leftKeyDown=false;}
        if(ke.getKeyCode()==68){rightKeyDown=false;}
        
        if(leftKeyDown==false&&rightKeyDown==false) mario.mario_is_moving=false;
    }    
    
}
