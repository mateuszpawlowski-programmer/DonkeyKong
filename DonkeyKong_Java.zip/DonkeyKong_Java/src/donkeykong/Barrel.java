package donkeykong;

import java.util.Random;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author M
 */
public class Barrel {

public int x=0;
public int y=0;

// right 6 left 4
public int direction=6;

public int currentPoint=-1;
public int moveToPoint=0;

public int level=1,r;

public int slope_counter=0;

public int animation_counter=0;
public int frame=0;

public Random random_path=new Random();

public Mario mario_ref;

Barrel(int x,int y,Mario m_ref)
{
    this.x=x;this.y=y;this.mario_ref=m_ref;
    //random_path.setSeed(System.currentTimeMillis());
}

public boolean checkCollisionWithMario()
{
    if((mario_ref.x+16)>x&&(mario_ref.y+32-10)>y&&(mario_ref.x+16)<(x+24)&&(mario_ref.y+32-10)<(y+16))
    {
    System.out.println("Barel Collision");
    return true;
    }
    return false;
}

public void move()
{
animation_counter++;
if(animation_counter==15) {animation_counter=0;frame++;if(frame==4) frame=0;}

if(currentPoint==-1&&moveToPoint==0){moveToPoint0();}    
if(currentPoint==0&&moveToPoint==1){moveToPoint1();}
if(currentPoint==0&&moveToPoint==7){moveToPoint7();}
if(currentPoint==1&&moveToPoint==2){moveToPoint2();}
if(currentPoint==2&&moveToPoint==5){moveToPoint5();}
if(currentPoint==2&&moveToPoint==3){moveToPoint3();}
if(currentPoint==3&&moveToPoint==4){moveToPoint4();}
if(currentPoint==4&&moveToPoint==5){moveToPoint5();}
if(currentPoint==5&&moveToPoint==6){moveToPoint6();}
if(currentPoint==6&&moveToPoint==7){moveToPoint7();}
if(currentPoint==6&&moveToPoint==16){moveToPoint16();}
if(currentPoint==7&&moveToPoint==8){moveToPoint8();}
if(currentPoint==8&&moveToPoint==9){moveToPoint9();}
if(currentPoint==8&&moveToPoint==14){moveToPoint14();}
if(currentPoint==9&&moveToPoint==10){moveToPoint10();}
if(currentPoint==9&&moveToPoint==12){moveToPoint12();}
if(currentPoint==10&&moveToPoint==11){moveToPoint11();}
if(currentPoint==11&&moveToPoint==12){moveToPoint12();}
if(currentPoint==12&&moveToPoint==13){moveToPoint13();}
if(currentPoint==13&&moveToPoint==14){moveToPoint14();}
if(currentPoint==13&&moveToPoint==23){moveToPoint23();}
if(currentPoint==14&&moveToPoint==15){moveToPoint15();}
if(currentPoint==15&&moveToPoint==16){moveToPoint16();}
if(currentPoint==15&&moveToPoint==21){moveToPoint21();}
if(currentPoint==16&&moveToPoint==17){moveToPoint17();}
if(currentPoint==17&&moveToPoint==18){moveToPoint18();}
if(currentPoint==17&&moveToPoint==20){moveToPoint20();}
if(currentPoint==18&&moveToPoint==19){moveToPoint19();}
if(currentPoint==19&&moveToPoint==20){moveToPoint20();}
if(currentPoint==20&&moveToPoint==21){moveToPoint21();}
if(currentPoint==21&&moveToPoint==22){moveToPoint22();}
if(currentPoint==22&&moveToPoint==23){moveToPoint23();}
if(currentPoint==23&&moveToPoint==24){moveToPoint24();}
if(currentPoint==24&&moveToPoint==25){moveToPoint25();}
if(currentPoint==25&&moveToPoint==26){moveToPoint26();}
if(currentPoint==24&&moveToPoint==27){moveToPoint27();}
if(currentPoint==22&&moveToPoint==29){moveToPoint29();}
if(currentPoint==26&&moveToPoint==27){moveToPoint27();}
if(currentPoint==27&&moveToPoint==28){moveToPoint28();}
if(currentPoint==28&&moveToPoint==29){moveToPoint29();}
if(currentPoint==28&&moveToPoint==35){moveToPoint35();}
if(currentPoint==29&&moveToPoint==30){moveToPoint30();}
if(currentPoint==30&&moveToPoint==31){moveToPoint31();}
if(currentPoint==30&&moveToPoint==33){moveToPoint33();}
if(currentPoint==31&&moveToPoint==32){moveToPoint32();}
if(currentPoint==32&&moveToPoint==33){moveToPoint33();}
if(currentPoint==33&&moveToPoint==34){moveToPoint34();}
if(currentPoint==34&&moveToPoint==35){moveToPoint35();}
if(currentPoint==35&&moveToPoint==36){moveToPoint36();}

if(currentPoint==-1||currentPoint==0||currentPoint==1||currentPoint==2||currentPoint==3) direction=6;
if(currentPoint==4||currentPoint==5||currentPoint==6||currentPoint==7||currentPoint==8||currentPoint==9||currentPoint==10) direction=4;
if(currentPoint==11||currentPoint==12||currentPoint==13||currentPoint==14||currentPoint==15||currentPoint==16||currentPoint==17||currentPoint==18) direction=6;
if(currentPoint==19||currentPoint==20||currentPoint==21||currentPoint==22||currentPoint==23||currentPoint==24||currentPoint==25) direction=4;
if(currentPoint==26||currentPoint==27||currentPoint==28||currentPoint==29||currentPoint==30||currentPoint==31||currentPoint==31) direction=6;
if(currentPoint==32||currentPoint==33||currentPoint==34||currentPoint==35||currentPoint==36) direction=4;
}


public void moveToPoint0()
{
    if(x<=175)
    {
    x++;
    }
    
    r=random_path.nextInt(2);
    
    if(x==175) 
    {
        if(r==1) {currentPoint=0;moveToPoint=7;}
        if(r==0) {currentPoint=0;moveToPoint=1;}
    }
}

public void moveToPoint1()
{
    if(level==1&&x<=250)
    {
    x++;
    }
    if(x==250) {currentPoint=1;moveToPoint=2;}
}

public void moveToPoint2()
{
    if(level==1&&x>=250&&x<365)
    {
    x++;
    slope_counter++;if(slope_counter==32){y=y+2;slope_counter=0;} 
    }
    
    r=random_path.nextInt(2);
    
    if(x==365)
    {
    if(r==1) {currentPoint=2;moveToPoint=5;}
    if(r==0) {currentPoint=2;moveToPoint=3;}
    }
}

public void moveToPoint3()
{
    if(level==1&&x>=250&&x<420)
    {
    x++;
    slope_counter++;if(slope_counter==32){y=y+2;slope_counter=0;} 
    }
    if(x==420) {currentPoint=3;moveToPoint=4;}
}

public void moveToPoint4()
{
    if(currentPoint==3){
        if(y<202)
        {
        y++;
        
        }
        if(y==202){currentPoint=4;moveToPoint=5;}
    }
    
}

public void moveToPoint5()
{
    if(currentPoint==2){
        if(level==1&&x>=365&&y<206)
        {
        y++;
        //slope_counter++;if(slope_counter==32){y=y+2;slope_counter=0;} 
        if(y==206) {currentPoint=5;moveToPoint=6;}    
        }
    }
    
    if(currentPoint==4)
    {
        if(x>=365)
        {
        x--;
        slope_counter++;if(slope_counter==32){y=y+2;slope_counter=0;} 
        }
        if(x==365) {currentPoint=5;moveToPoint=6;}    
    }
}

public void moveToPoint6()
{
    if(x>=335)
    {
    x--;
    slope_counter++;if(slope_counter==32){y=y+2;slope_counter=0;} 
    }
    
    r=random_path.nextInt(2);
    
    if(x==335)
    {
    if(r==1) {currentPoint=6;moveToPoint=7;}
    if(r==0) {currentPoint=6;moveToPoint=16;}
    }
}

public void moveToPoint7()
{
    if(currentPoint==6){
        if(x>=175)
        {
        x--;
        slope_counter++;if(slope_counter==32){y=y+2;slope_counter=0;} 
        if(x==175){currentPoint=7;moveToPoint=8;}
        }
    }
    if(currentPoint==0)
    {
    y++;
    if(y==220){currentPoint=7;moveToPoint=8;}
    }
    
    //if(x==175){currentPoint=7;moveToPoint=8;}
}

public void moveToPoint8()
{
    if(currentPoint==7)
    {
        if(x>=140)
        {
        x--;
        slope_counter++;if(slope_counter==32){y=y+2;slope_counter=0;} 
        }
        
        r=random_path.nextInt(2);
        
        if(x==140)
        {
            if(r==1){currentPoint=8;moveToPoint=9;}
            if(r==0){currentPoint=8;moveToPoint=14;}
        }
        
    }
    
}

public void moveToPoint9()
{
    if(currentPoint==8)
    {
        
        r=random_path.nextInt(2);
        
        if(x>=60)
        {
        x--;
        slope_counter++;if(slope_counter==32){y=y+2;slope_counter=0;} 
        }
        
        if(x==60)
        {
            if(r==1){currentPoint=9;moveToPoint=10;}
            if(r==0){currentPoint=9;moveToPoint=12;}
        }
        
    }
}

public void moveToPoint10()
{
    if(currentPoint==9)
    {
        if(x>=5)
        {
        x--;
        slope_counter++;if(slope_counter==32){y=y+2;slope_counter=0;} 
        }
        if(x==5){currentPoint=10;moveToPoint=11;}
    }
}

public void moveToPoint11()
{
    if(currentPoint==10){
        if(y<=268)
        {
        y++;
        
        }
        if(y==268){currentPoint=11;moveToPoint=12;}
    }
    
}

public void moveToPoint12()
{
    if(currentPoint==11)
    {
        if(x<=65)
        {
        x++;
        slope_counter++;if(slope_counter==32){y=y+2;slope_counter=0;} 
        }
        if(x==65){currentPoint=12;moveToPoint=13;}
    }
    
    if(currentPoint==9)
    {
        if(y<=272)
        {
        y++;
        }
        if(y==272){currentPoint=12;moveToPoint=13;}
    }
}

public void moveToPoint13()
{
    if(currentPoint==12)
    {
        if(x<=125)
        {
        x++;
        slope_counter++;if(slope_counter==32){y=y+2;slope_counter=0;} 
        }
        
        r=random_path.nextInt(2);
        
        if(x==125)
        {
        if(r==1) {currentPoint=13;moveToPoint=14;}
        if(r==0) {currentPoint=13;moveToPoint=23;}
        }
    }
}

public void moveToPoint14()
{
    if(currentPoint==8){
        if(y<=275)
        {
        y++;
        
        }
        //if(y==202){currentPoint=4;moveToPoint=5;}
        if(y==275){currentPoint=14;moveToPoint=15;}
    }
    
    if(currentPoint==13)
    {
        if(x<=140)
        {
        x++;
        slope_counter++;if(slope_counter==32){y=y+2;slope_counter=0;} 
        }
        if(x==140){currentPoint=14;moveToPoint=15;}
    }
}

public void moveToPoint15()
{
    if(currentPoint==14)
    {
        if(x<=220)
        {
        x++;
        slope_counter++;if(slope_counter==32){y=y+2;slope_counter=0;} 
        }
        
        r=random_path.nextInt(2);
        
        if(x==220){
            if(r==1) {currentPoint=15;moveToPoint=16;}
            if(r==0) {currentPoint=15;moveToPoint=21;}
        }
        
    }
}

public void moveToPoint16()
{
    if(currentPoint==6)
    {
        if(y<=290)
        {
        y++;
        }
        if(y==290){currentPoint=16;moveToPoint=17;}
    }
    
    if(currentPoint==15)
    {
        if(x<=330)
        {
        x++;
        slope_counter++;if(slope_counter==32){y=y+2;slope_counter=0;} 
        }
        if(x==330){currentPoint=16;moveToPoint=17;}
    }
}

public void moveToPoint17()
{
    if(currentPoint==16)
    {
        if(x<=365)
        {
        x++;
        slope_counter++;if(slope_counter==32){y=y+2;slope_counter=0;} 
        }
        
        r=random_path.nextInt(2);
        
        
        if(x==365){
            if(r==1) {currentPoint=17;moveToPoint=18;}
            if(r==0) {currentPoint=17;moveToPoint=20;}
        }
    }
}

public void moveToPoint18()
{
    if(currentPoint==17)
    {
        if(x<=420)
        {
        x++;
        slope_counter++;if(slope_counter==32){y=y+2;slope_counter=0;} 
        }
        if(x==420){currentPoint=18;moveToPoint=19;}
    }
}

public void moveToPoint19()
{
    if(currentPoint==18){
        if(y<=335)
        {
        y++;
        
        }
        if(y==335){currentPoint=19;moveToPoint=20;}
    }
    
    
}

public void moveToPoint20()
{
    if(currentPoint==17){
        if(y<=337)
        {
        y++;
        
        }
        if(y==337){currentPoint=20;moveToPoint=21;}
    }
    
    if(currentPoint==19){
        if(x>=365)
        {
        x--;
        slope_counter++;if(slope_counter==32){y=y+2;slope_counter=0;} 
        }
        if(x==365){currentPoint=20;moveToPoint=21;}
    }
    
    
}

public void moveToPoint21()
{
    if(currentPoint==15){
        if(y<=345)
        {
        y++;
        
        }
        if(y==345){currentPoint=21;moveToPoint=22;}
    }
    
    if(currentPoint==20){
        if(x>=220)
        {
        x--;
        slope_counter++;if(slope_counter==32){y=y+2;slope_counter=0;} 
        }
        if(x==220){currentPoint=21;moveToPoint=22;}
    }
    
    
}

public void moveToPoint22()
{
     if(currentPoint==21){
        if(x>=190)
        {
        x--;
        slope_counter++;if(slope_counter==32){y=y+2;slope_counter=0;} 
        }
        
        r=random_path.nextInt(2);
        
        if(x==190)
        {
            if(r==1) {currentPoint=22;moveToPoint=23;}
            if(r==0) {currentPoint=22;moveToPoint=29;}
        }
    }
}

public void moveToPoint23()
{
    if(currentPoint==13){
        if(y<=352)
        {
        y++;
        
        }
        if(y==352){currentPoint=23;moveToPoint=24;}
    }

    if(currentPoint==22){
        if(x>=125)
        {
        x--;
        slope_counter++;if(slope_counter==32){y=y+2;slope_counter=0;} 
        }
        if(x==125){currentPoint=23;moveToPoint=24;}
    }    
    
}

public void moveToPoint24()
{
    if(currentPoint==23){
        if(x>=60)
        {
        x--;
        slope_counter++;if(slope_counter==32){y=y+2;slope_counter=0;} 
        }
        
        r=random_path.nextInt(2);
        
        if(x==60)
        {
            if(r==1) {currentPoint=24;moveToPoint=25;}
            if(r==0) {currentPoint=24;moveToPoint=27;}
        }
    }    
}

public void moveToPoint25()
{
    if(currentPoint==24){
        if(x>=5)
        {
        x--;
        slope_counter++;if(slope_counter==32){y=y+2;slope_counter=0;} 
        }
        if(x==5){currentPoint=25;moveToPoint=26;}
    }    
}

public void moveToPoint26()
{
        if(y<=400)
        {
        y++;
        }
        if(y==400){currentPoint=26;moveToPoint=27;}
}

public void moveToPoint27()
{
    if(currentPoint==26)
    {
        if(x<=60)
        {
        x++;
        slope_counter++;if(slope_counter==32){y=y+2;slope_counter=0;} 
        }
        if(x==60){currentPoint=27;moveToPoint=28;}
    }
    
    if(currentPoint==24){
        if(y<=404)
        {
        y++;
        }
        if(y==404){currentPoint=27;moveToPoint=28;}
    }
}

public void moveToPoint28()
{
    if(currentPoint==27)
    {
        if(x<=160)
        {
        x++;
        slope_counter++;if(slope_counter==32){y=y+2;slope_counter=0;} 
        }
        
        r=random_path.nextInt(2);
        
        if(x==160)
        {
            if(r==1) {currentPoint=28;moveToPoint=29;}
            if(r==0) {currentPoint=28;moveToPoint=35;}
        }
    }
}

public void moveToPoint29()
{
    if(currentPoint==22){
        if(y<=412)
        {
        y++;
        }
        if(y==412){currentPoint=29;moveToPoint=30;}
    }
    
    if(currentPoint==28)
    {
        if(x<=190)
        {
        x++;
        slope_counter++;if(slope_counter==32){y=y+2;slope_counter=0;} 
        }
        if(x==190){currentPoint=29;moveToPoint=30;}
    }
}

public void moveToPoint30()
{
    if(currentPoint==29)
    {
        if(x<=365)
        {
        x++;
        slope_counter++;if(slope_counter==32){y=y+2;slope_counter=0;} 
        }
        
        r=random_path.nextInt(2);
        
        if(x==365)
        {
            if(r==1) {currentPoint=30;moveToPoint=31;}
            if(r==0) {currentPoint=30;moveToPoint=33;}
        }
    }
}

public void moveToPoint31()
{
    if(currentPoint==30)
    {
        if(x<=420)
        {
        x++;
        slope_counter++;if(slope_counter==32){y=y+2;slope_counter=0;} 
        }
        if(x==420){currentPoint=31;moveToPoint=32;}
    }
}

public void moveToPoint32()
{
    if(currentPoint==31){
        if(y<=466)
        {
        y++;
        }
    }
    if(y==466){currentPoint=32;moveToPoint=33;}
}

public void moveToPoint33()
{
    if(currentPoint==30)
    {
        if(y<=468)
        {
        y++;
        }
    
        if(y==468){currentPoint=33;moveToPoint=34;}
    }
    
    if(currentPoint==32){
        if(x>=365)
        {
        x--;
        slope_counter++;if(slope_counter==32){y=y+2;slope_counter=0;} 
        }
        if(x==365){currentPoint=33;moveToPoint=34;}
    }
}

public void moveToPoint34()
{
        if(x>=215)
        {
        x--;
        slope_counter++;if(slope_counter==32){y=y+2;slope_counter=0;} 
        }
        if(x==215){currentPoint=34;moveToPoint=35;y=y+2;}
}

public void moveToPoint35()
{
    if(currentPoint==28)
    {
    
        if(y<=480)
        {
        y++;
        }
    
        if(y==480){currentPoint=35;moveToPoint=36;}
    }
    
    if(currentPoint==34){
        if(x>=155)
        {
        x--;
        
        }
        
        if(x==155){currentPoint=35;moveToPoint=36;}
    }
    
}

public void moveToPoint36()
{
        if(x>=-30)
        {
        x--;
        //slope_counter++;if(slope_counter==32){y=y+2;slope_counter=0;} 
        }
        if(x==-30)
        
        {
            //currentPoint=36;moveToPoint=37;
        
            x=55;y=152;
            currentPoint=-1;
            moveToPoint=0;
            slope_counter=0;
        }
}

}
